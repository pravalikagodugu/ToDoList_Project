import { atom } from "recoil";

export const editState = atom({
  key: "EditState",
  default: false,
});
