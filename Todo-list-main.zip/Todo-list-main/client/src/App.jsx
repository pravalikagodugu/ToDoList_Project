import { useState } from "react";
import "./App.css";

function App() {
  return (
    <main>
      <h1>Todo List React</h1>
    </main>
  );
}

export default App;
